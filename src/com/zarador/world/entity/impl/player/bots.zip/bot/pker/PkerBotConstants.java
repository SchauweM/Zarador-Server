package com.runelive.world.entity.impl.player.bot.pker;

public class PkerBotConstants 
{
	
	public static int START_WILDY_X = 3042;
	
	public static int START_WILDY_Y = 3525;
	
	public static int END_WILDY_X = 3102;
	
	public static int END_WILDY_Y = 3557;
	
	public static int START_HOME_X = 3084;
	
	public static int START_HOME_Y = 3487;
	
	public static int END_HOME_X = 3090;
	
	public static int END_HOME_Y = 3492;

	/*public static int START_WILDY_X = 3206;
	
	public static int START_WILDY_Y = 3525;
	
	public static int END_WILDY_X = 3255;
	
	public static int END_WILDY_Y = 3546;*/
	
}
