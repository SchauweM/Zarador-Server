package com.runelive.world.entity.impl.player.bot.segment;

import java.util.Objects;
import java.util.Optional;

import com.runelive.model.Flag;
import com.runelive.model.Item;
import com.runelive.model.Position;
import com.runelive.model.Locations.Location;
import com.runelive.model.action.distance.FollowMobileAction;
import com.runelive.world.World;
import com.runelive.world.content.combat.CombatFactory;
import com.runelive.world.content.transportation.TeleportHandler;
import com.runelive.world.entity.impl.player.Player;
import com.runelive.world.entity.impl.player.bot.Bot;
import com.runelive.world.entity.impl.player.bot.BotTask;
import com.runelive.world.entity.impl.player.bot.characteristics.BotCharacteristics;
import com.runelive.world.entity.impl.player.bot.characteristics.Spell;


public abstract class  BotSegment {

	protected final Bot bot;

	public BotSegment(Bot bot) {
		this.bot = bot;
//		equip(EquipmentSlots.WEAPON, 1321);
	}

	public abstract boolean canExec();

	public abstract int execute();

	protected int teleport() {
		teleport(3087, 3498);
		return 5;
	}

	public void teleport(int x, int y) {
		TeleportHandler.teleportPlayer(bot, new Position(x, y, 0), bot.getSpellbook().getTeleportType());
	}

	public BotCharacteristics chars() {
		return bot.getCharacteristics();
	}

	public boolean equipmentContains(int id) {
		return bot.getEquipment().contains(id);
	}

	public boolean inventoryContains(int id) {
		for (Item item : bot.getInventory().getItems()) {
			if (item != null) {
				if (item.getId() == id) {
					return true;
				}
			}
		}
		return false;
	}

	public Optional<Item> obtainEquipment(int slot) {
		return Optional.ofNullable(bot.getEquipment().get(slot));
	}

	public boolean equipmentFree(int slot) {
		return !obtainEquipment(slot).isPresent();
	}

	public void equip(int slot, int id) {
		Item contained = bot.getEquipment().get(slot);
		if (contained != null) {
			if (contained.getId() == id) {
				return;
			}
			addInvent(contained);
		}
		bot.getEquipment().getItems()[slot] = new Item(id, 1);
		bot.getUpdateFlag().flag(Flag.APPEARANCE);
	}

	public void addInvent(Item item) {
		bot.getInventory().add(item.getId(), item.getAmount());
	}

	public void addInvent(int id, int amount) {
		bot.getInventory().add(id, amount);
	}

	public void attack() {
		target().ifPresent(t -> {
			attack(t);
		});
	}
	
	public void attackMage(Spell spell) {
		target().ifPresent(t -> {
			attackMage(spell, t);
		});
	}
	
	public void attackMage(Spell spell, Player targ) {
		//TODO: Set spell to #SPELL
		attack(targ);
	}
	
	public void attack(Player attacked) {
		if (this.bot.getUsername().equalsIgnoreCase(BotTask.TESTING)) {
			System.out.println("Attempting to attack: " + attacked.getUsername());
		}
		if (!bot.getDragonSpear().elapsed(3000)) {
			bot.getPacketSender().sendMessage("You can't do that, you're stunned!");
			return;
		}
		if (bot.getCombatBuilder().getStrategy() == null) {
			bot.getCombatBuilder().determineStrategy();
		}
		if (CombatFactory.checkAttackDistance(bot, attacked)) {
			bot.getWalkingQueue().clear();
		}

		bot.getCombatBuilder().attack(attacked);
	}
	
	public void follow() {
		target().ifPresent(this::follow);
	}
	
	public void follow(Player other) {
		bot.getCombatBuilder().reset();
		bot.setEntityInteraction(other);
		bot.getActionQueue().addAction(new FollowMobileAction(bot, other));
	}

	public double getHealthPercentage() {
		return (getCurrentHealth() / getMaximumHealth()) * 100;
	}

	public double getMaximumHealth() {
		return bot.getMaximumHealth();
	}

	public double getCurrentHealth() {
		return bot.getConstitution();
	}

	public boolean inFight() {
		return target().isPresent();
	}

	public Optional<Player> target() {
		return World
				.getPlayers()
				.stream()
				.filter(Objects::nonNull)
				.filter(player -> Math.abs(player.getSkillManager()
						.getCombatLevel()
						- bot.getSkillManager().getCombatLevel()) <= 5)
		//		.filter(player -> player.getCombatBuilder().isAttacking())
				.filter(player -> player.getCombatBuilder().getVictim() == bot)
				.findAny();
	}

}
